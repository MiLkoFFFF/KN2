﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace DomServices
{
    public partial class EditRequestWindow : Window
    {
        private string connectionString = @"Data Source=dbsrv\GLO2024;Initial Catalog=DomServices;Integrated Security=True";

        private int requestId;
        private List<Master> mastersList = new List<Master>();

        public EditRequestWindow(RequestViewModel request)
        {
            InitializeComponent();

            requestId = request.Id_Req;

            StatusComboBox.ItemsSource = Enum.GetValues(typeof(RequestStatus));
            StatusComboBox.SelectedItem = request.Status;

            LoadMasters();

            MastersComboBox.SelectedValue = GetMasterIdName(request.MasterName);
        }

        private void LoadMasters()
        {
            mastersList.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Id_Mast, FName FROM Masters";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        mastersList.Add(new Master
                        {
                            Id_Mast = reader.GetInt32(0),
                            FName = reader.GetString(1)
                        });
                    }
                }
            }

            MastersComboBox.ItemsSource = mastersList;
            MastersComboBox.DisplayMemberPath = "FName";
            MastersComboBox.SelectedValuePath = "Id_Mast";
        }

        private int GetMasterIdName(string masterName)
        {
            var master = mastersList.Find(m => m.FName == masterName);
            return master != null ? master.Id_Mast : -1;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (StatusComboBox.SelectedItem == null || MastersComboBox.SelectedValue == null)
            {
                MessageBox.Show("Пожалуйста, выберите статус и мастера.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var selectedStatus = (RequestStatus)StatusComboBox.SelectedItem;
            int selectedMasterId = (int)MastersComboBox.SelectedValue;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string updateQuery = @"
                    UPDATE Requests 
                    SET Status = @Status, FK_Masters = @MasterId 
                    WHERE Id_Req = @Id";

                using (SqlCommand cmd = new SqlCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Status", (int)selectedStatus);
                    cmd.Parameters.AddWithValue("@MasterId", selectedMasterId);
                    cmd.Parameters.AddWithValue("@Id", requestId);

                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Заявка успешно обновлена!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.DialogResult = true;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при обновлении заявки.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
