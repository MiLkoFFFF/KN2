﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace DomServices
{
    public partial class RequestsWindow : Window
    {
        private string connectionString = @"Data Source=dbsrv\GLO2024;Initial Catalog=DomServices;Integrated Security=True";

        public RequestsWindow()
        {
            InitializeComponent();
            LoadRequests();
        }

        private void LoadRequests()
        {
            var requests = new List<RequestViewModel>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = @"
                    SELECT r.Id_Req, r.Title, r.Problem, r.Type, r.Status, m.FName
                    FROM Requests r
                    LEFT JOIN Masters m ON r.FK_Masters = m.Id_Mast";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        requests.Add(new RequestViewModel
                        {
                            Id_Req = reader.GetInt32(0),
                            Title = reader.GetString(1),
                            Problem = reader.GetString(2),
                            Type = reader.GetString(3),
                            Status = (RequestStatus)reader.GetInt32(4),
                            MasterName = reader.IsDBNull(5) ? "Не назначен" : reader.GetString(5)
                        });
                    }
                }
            }

            RequestsListView.ItemsSource = requests;
        }

        private void CreateRequestButton_Click(object sender, RoutedEventArgs e)
        {
            CreateRequestWindow createWindow = new CreateRequestWindow();
            createWindow.Show();
            this.Close();
        }

        private void EditRequestButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is RequestViewModel selectedRequest)
            {
                var editWindow = new EditRequestWindow(selectedRequest);
                bool? result = editWindow.ShowDialog();

                if (result == true)
                {
                    LoadRequests();
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку для изменения.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }


        private void DeleteRequestButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is RequestViewModel selectedRequest)
            {
                var result = MessageBox.Show("Вы действительно хотите удалить эту заявку?", "Удаление заявки", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        string deleteQuery = "DELETE FROM Requests WHERE Id_Req = @Id";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@Id", selectedRequest.Id_Req);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadRequests();
                }
            }
            else
            {
                MessageBox.Show("Выберите заявку для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }

    public class RequestViewModel
    {
        public int Id_Req { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string Problem { get; set; }
        public RequestStatus Status { get; set; }
        public string MasterName { get; set; }

        public string StatusName
        {
            get
            {
                switch (Status)
                {
                    case RequestStatus.ВОбработке: return "В обработке";
                    case RequestStatus.ВРаботе: return "В работе";
                    default: return "Завершена";
                }
            }
        }
    }

    public enum RequestStatus
    {
        ВОбработке = 0,
        ВРаботе = 1,
        Завершена = 2
    }
}
