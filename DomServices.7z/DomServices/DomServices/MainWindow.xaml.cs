﻿using System.Windows;

namespace DomServices
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ViewRequestsButton_Click(object sender, RoutedEventArgs e)
        {
            RequestsWindow requestsWindow = new RequestsWindow();
            requestsWindow.Show();
            this.Close();
        }

        private void CreateRequestButton_Click(object sender, RoutedEventArgs e)
        {
            CreateRequestWindow createRequestWindow = new CreateRequestWindow();
            createRequestWindow.Show();
            this.Close();
        }
    }
}
