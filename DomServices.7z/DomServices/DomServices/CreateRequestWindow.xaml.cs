﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace DomServices
{
    public partial class CreateRequestWindow : Window
    {
        private string connectionString = @"Data Source=dbsrv\GLO2024;Initial Catalog=DomServices;Integrated Security=True";

        private List<Master> mastersList = new List<Master>();

        public CreateRequestWindow()
        {
            InitializeComponent();
            LoadMasters();
        }

        private void LoadMasters()
        {
            mastersList.Clear();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT Id_Mast, FName FROM Masters";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        mastersList.Add(new Master
                        {
                            Id_Mast = reader.GetInt32(0),
                            FName = reader.GetString(1)
                        });
                    }
                }
            }

            MastersComboBox.ItemsSource = mastersList;
            MastersComboBox.DisplayMemberPath = "FName";
            MastersComboBox.SelectedValuePath = "Id_Mast";
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            string title = TitleTextBox.Text.Trim();
            string type = TypeTextBox.Text.Trim();
            string problem = ProblemTextBox.Text.Trim();
            int? selectedMasterId = MastersComboBox.SelectedValue as int?;

            if (string.IsNullOrEmpty(title) || string.IsNullOrEmpty(type) || string.IsNullOrEmpty(problem))
            {
                MessageBox.Show("Пожалуйста, заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MastersComboBox.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите мастера", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string insertQuery = @"
                    INSERT INTO Requests (Title, Type, Problem, CreatedDate, Status, FK_Masters)
                    VALUES (@Title, @Type, @Problem, @CreatedDate, @Status, @FK_Masters)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Title", title);
                    cmd.Parameters.AddWithValue("@Type", type);
                    cmd.Parameters.AddWithValue("@Problem", problem);
                    cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now.Date);
                    cmd.Parameters.AddWithValue("@Status", (int)RequestStatus.ВОбработке);
                    cmd.Parameters.AddWithValue("@FK_Masters", (int)MastersComboBox.SelectedValue);

                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Заявка успешно создана!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        RequestsWindow requestsWindow = new RequestsWindow();
                        requestsWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при создании заявки.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }

    public class Master
    {
        public int Id_Mast { get; set; }
        public string FName { get; set; }
    }
}
