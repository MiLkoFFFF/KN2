﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace DomServices
{
    public partial class RegisterWindow : Window
    {
        private string connectionString = @"Data Source=dbsrv\GLO2024;Initial Catalog=DomServices;Integrated Security=True";

        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password;
            string fullName = FNameTextBox.Text.Trim();
            string phone = PhoneTextBox.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(fullName))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string checkQuery = "SELECT COUNT(*) FROM Masters WHERE Login = @Login";
                using (SqlCommand checkCmd = new SqlCommand(checkQuery, conn))
                {
                    checkCmd.Parameters.AddWithValue("@Login", login);
                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Логин занят.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                }

                string insertQuery = @"
                    INSERT INTO Masters (Login, Password, RegistrationDate, FName, Phone) 
                    VALUES (@Login, @Password, @RegistrationDate, @FName, @Phone)";

                using (SqlCommand insertCmd = new SqlCommand(insertQuery, conn))
                {
                    insertCmd.Parameters.AddWithValue("@Login", login);
                    insertCmd.Parameters.AddWithValue("@Password", password);
                    insertCmd.Parameters.AddWithValue("@RegistrationDate", DateTime.Now.Date);
                    insertCmd.Parameters.AddWithValue("@FName", fullName);
                    insertCmd.Parameters.AddWithValue("@Phone", phone);

                    int rows = insertCmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Регистрация прошла успешно. Теперь вы можете войти.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoginWindow loginWindow = new LoginWindow();
                        loginWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при регистрации.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
